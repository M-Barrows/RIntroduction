library(testthat)
library("TestRC")

test_check("TestRC")
