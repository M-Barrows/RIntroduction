library(testthat)
library("TestParallel")

test_check("TestParallel")
